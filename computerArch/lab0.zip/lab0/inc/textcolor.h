#ifndef JOS_INC_TEXT_COLOR_H
#define JOS_INC_TEXT_COLOR_H

int textcolor;

#endif
