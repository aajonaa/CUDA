// Stripped-down primitive printf-style formatting routines,
// used in common by printf, sprintf, fprintf, etc.
// This code is also used by both the kernel and user programs.

#include <inc/types.h>
#include <inc/stdio.h>
#include <inc/string.h>
#include <inc/stdarg.h>
#include <inc/error.h>
/* I add this line */
#include <inc/stdint.h>
#include <inc/textcolor.h>

/*
 * Space or zero padding and a field width are supported for the numeric
 * formats only.
 *
 * The special format %e takes an integer error code
 * and prints a string describing the error.
 * The integer may be positive or negative,
 * so that -E_NO_MEM and E_NO_MEM are equivalent.
 */

/* I copy the code here */
 /** On x86, division of one 64-bit integer by another cannot be
    done with a single instruction or a short sequence.  Thus, GCC
    implements 64-bit division and remainder operations through
    function calls.  These functions are normally obtained from
    libgcc, which is automatically included by GCC in any link
    that it does.
  
    Some x86-64 machines, however, have a compiler and utilities
    that can generate 32-bit x86 code without having any of the
    necessary libraries, including libgcc.  Thus, we can make
    Pintos work on these machines by simply implementing our own
    64-bit division routines, which are the only routines from
    libgcc that Pintos requires.
  
    Completeness is another reason to include these routines.  If
    Pintos is completely self-contained, then that makes it that
    much less mysterious. */
  
 /** Uses x86 DIVL instruction to divide 64-bit N by 32-bit D to
    yield a 32-bit quotient.  Returns the quotient.
    Traps with a divide error (#DE) if the quotient does not fit
    in 32 bits. */
 static inline uint32_t
 divl (uint64_t n, uint32_t d)
 {
   uint32_t n1 = n >> 32;
   uint32_t n0 = n;
   uint32_t q, r;
  
   asm ("divl %4"
        : "=d" (r), "=a" (q)
        : "0" (n1), "1" (n0), "rm" (d));
  
   return q;
 }
  
 /** Returns the number of leading zero bits in X,
    which must be nonzero. */
 static int
 nlz (uint32_t x) 
 {
   /* This technique is portable, but there are better ways to do
      it on particular systems.  With sufficiently new enough GCC,
      you can use __builtin_clz() to take advantage of GCC's
      knowledge of how to do it.  Or you can use the x86 BSR
      instruction directly. */
   int n = 0;
   if (x <= 0x0000FFFF)
     {
       n += 16;
       x <<= 16; 
     }
   if (x <= 0x00FFFFFF)
     {
       n += 8;
       x <<= 8; 
     }
   if (x <= 0x0FFFFFFF)
     {
       n += 4;
       x <<= 4;
     }
   if (x <= 0x3FFFFFFF)
     {
       n += 2;
       x <<= 2; 
     }
   if (x <= 0x7FFFFFFF)
     n++;
   return n;
 }
  
 /** Divides unsigned 64-bit N by unsigned 64-bit D and returns the
    quotient. */
 static uint64_t
 udiv64 (uint64_t n, uint64_t d)
 {
   if ((d >> 32) == 0) 
     {
       /* Proof of correctness:
  
          Let n, d, b, n1, and n0 be defined as in this function.
          Let [x] be the "floor" of x.  Let T = b[n1/d].  Assume d
          nonzero.  Then:
              [n/d] = [n/d] - T + T
                    = [n/d - T] + T                         by (1) below
                    = [(b*n1 + n0)/d - T] + T               by definition of n
                    = [(b*n1 + n0)/d - dT/d] + T
                    = [(b(n1 - d[n1/d]) + n0)/d] + T
                    = [(b[n1 % d] + n0)/d] + T,             by definition of %
          which is the expression calculated below.
  
          (1) Note that for any real x, integer i: [x] + i = [x + i].
  
          To prevent divl() from trapping, [(b[n1 % d] + n0)/d] must
          be less than b.  Assume that [n1 % d] and n0 take their
          respective maximum values of d - 1 and b - 1:
                  [(b(d - 1) + (b - 1))/d] < b
              <=> [(bd - 1)/d] < b
              <=> [b - 1/d] < b
          which is a tautology.
  
          Therefore, this code is correct and will not trap. */
       uint64_t b = 1ULL << 32;
       uint32_t n1 = n >> 32;
       uint32_t n0 = n; 
       uint32_t d0 = d;
  
       return divl (b * (n1 % d0) + n0, d0) + b * (n1 / d0); 
     }
   else 
     {
       /* Based on the algorithm and proof available from
          http://www.hackersdelight.org/revisions.pdf. */
       if (n < d)
         return 0;
       else 
         {
           uint32_t d1 = d >> 32;
           int s = nlz (d1);
           uint64_t q = divl (n >> 1, (d << s) >> 32) >> (31 - s);
           return n - (q - 1) * d < d ? q - 1 : q; 
         }
     }
 }
  
 /** Divides unsigned 64-bit N by unsigned 64-bit D and returns the
    remainder. */
 static uint32_t
 umod64 (uint64_t n, uint64_t d)
 {
   return n - d * udiv64 (n, d);
 }
  
 /** Divides signed 64-bit N by signed 64-bit D and returns the
    quotient. */
 static int64_t
 sdiv64 (int64_t n, int64_t d)
 {
   uint64_t n_abs = n >= 0 ? (uint64_t) n : -(uint64_t) n;
   uint64_t d_abs = d >= 0 ? (uint64_t) d : -(uint64_t) d;
   uint64_t q_abs = udiv64 (n_abs, d_abs);
   return (n < 0) == (d < 0) ? (int64_t) q_abs : -(int64_t) q_abs;
 }
  
 /** Divides signed 64-bit N by signed 64-bit D and returns the
    remainder. */
 static int32_t
 smod64 (int64_t n, int64_t d)
 {
   return n - d * sdiv64 (n, d);
 }
 
 /** These are the routines that GCC calls. */
  
 long long __divdi3 (long long n, long long d);
 long long __moddi3 (long long n, long long d);
 unsigned long long __udivdi3 (unsigned long long n, unsigned long long d);
 unsigned long long __umoddi3 (unsigned long long n, unsigned long long d);
  
 /** Signed 64-bit division. */
 long long
 __divdi3 (long long n, long long d) 
 {
   return sdiv64 (n, d);
 }
  
 /** Signed 64-bit remainder. */
 long long
 __moddi3 (long long n, long long d) 
 {
   return smod64 (n, d);
 }
  
 /** Unsigned 64-bit division. */
 unsigned long long
 __udivdi3 (unsigned long long n, unsigned long long d) 
 {
   return udiv64 (n, d);
 }
  
 /** Unsigned 64-bit remainder. */
 unsigned long long
 __umoddi3 (unsigned long long n, unsigned long long d) 
 {
   return umod64 (n, d);
 }



static const char * const error_string[MAXERROR] =
{
	[E_UNSPECIFIED]	= "unspecified error",
	[E_BAD_ENV]	= "bad environment",
	[E_INVAL]	= "invalid parameter",
	[E_NO_MEM]	= "out of memory",
	[E_NO_FREE_ENV]	= "out of environments",
	[E_FAULT]	= "segmentation fault",
};

/*
 * Print a number (base <= 16) in reverse order,
 * using specified putch function and associated pointer putdat.
 */
static void
printnum(void (*putch)(int, void*), void *putdat,
	 unsigned long long num, unsigned base, int width, int padc)
{
	// first recursively print all preceding (more significant) digits
	if (num >= base) {
		printnum(putch, putdat, num / base, base, width - 1, padc);
	} else {
		// print any needed pad characters before first digit
		while (--width > 0)
			putch(padc, putdat);
	}

	// then print this (the least significant) digit
	putch("0123456789abcdef"[num % base], putdat);
}

// Get an unsigned int of various possible sizes from a varargs list,
// depending on the lflag parameter.
static unsigned long long
getuint(va_list *ap, int lflag)
{
	if (lflag >= 2)
		return va_arg(*ap, unsigned long long);
	else if (lflag)
		return va_arg(*ap, unsigned long);
	else
		return va_arg(*ap, unsigned int);
}

// Same as getuint but signed - can't use getuint
// because of sign extension
static long long
getint(va_list *ap, int lflag)
{
	if (lflag >= 2)
		return va_arg(*ap, long long);
	else if (lflag)
		return va_arg(*ap, long);
	else
		return va_arg(*ap, int);
}


// Main function to format and print a string.
void printfmt(void (*putch)(int, void*), void *putdat, const char *fmt, ...);

void
vprintfmt(void (*putch)(int, void*), void *putdat, const char *fmt, va_list ap)
{
	register const char *p;
	register int ch, err;
	unsigned long long num;
	int base, lflag, width, precision, altflag;
	char padc;

	while (1) {
		while ((ch = *(unsigned char *) fmt++) != '%') {
			if (ch == '\0')
					{	
						textcolor = 0x0700;
				return;
					}
			putch(ch, putdat);
		}

		// Process a %-escape sequence
		padc = ' ';
		width = -1;
		precision = -1;
		lflag = 0;
		altflag = 0;
	reswitch:
		switch (ch = *(unsigned char *) fmt++) {

		// flag to pad on the right
		case '-':
			padc = '-';
			goto reswitch;

		// flag to pad with 0's instead of spaces
		case '0':
			padc = '0';
			goto reswitch;

		// width field
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			for (precision = 0; ; ++fmt) {
				precision = precision * 10 + ch - '0';
				ch = *fmt;
				if (ch < '0' || ch > '9')
					break;
			}
			goto process_precision;

		case '*':
			precision = va_arg(ap, int);
			goto process_precision;

		case '.':
			if (width < 0)
				width = 0;
			goto reswitch;

		case '#':
			altflag = 1;
			goto reswitch;

		process_precision:
			if (width < 0)
				width = precision, precision = -1;
			goto reswitch;

		// long flag (doubled for long long)
		case 'l':
			lflag++;
			goto reswitch;

		// character
		case 'c':
			putch(va_arg(ap, int), putdat);
			break;

		// error message
		case 'e':
			err = va_arg(ap, int);
			if (err < 0)
				err = -err;
			if (err >= MAXERROR || (p = error_string[err]) == NULL)
				printfmt(putch, putdat, "error %d", err);
			else
				printfmt(putch, putdat, "%s", p);
			break;

		// string
		case 's':
			if ((p = va_arg(ap, char *)) == NULL)
				p = "(null)";
			if (width > 0 && padc != '-')
				for (width -= strnlen(p, precision); width > 0; width--)
					putch(padc, putdat);
			for (; (ch = *p++) != '\0' && (precision < 0 || --precision >= 0); width--)
				if (altflag && (ch < ' ' || ch > '~'))
					putch('?', putdat);
				else
					putch(ch, putdat);
			for (; width > 0; width--)
				putch(' ', putdat);
			break;

		// (signed) decimal
		case 'd':
			num = getint(&ap, lflag);
			if ((long long) num < 0) {
				putch('-', putdat);
				num = -(long long) num;
			}
			base = 10;
			goto number;

		// unsigned decimal
		case 'u':
			num = getuint(&ap, lflag);
			base = 10;
			goto number;

		// (unsigned) octal
		//case 'o'://
			// Replace this with your code.
		//	putch('X', putdat);//
		//	putch('X', putdat);//
		//	putch('X', putdat);//
		//	break;//
		case 'o':
			num = getuint(&ap, lflag);
			base = 8;
			goto number;

		// text color
		case 'm':
			num = getint(&ap, lflag);
			textcolor = num;
			break;

		// pointer
		case 'p':
			putch('0', putdat);
			putch('x', putdat);
			num = (unsigned long long)
				(uintptr_t) va_arg(ap, void *);
			base = 16;
			goto number;

		// (unsigned) hexadecimal
		case 'x':
			num = getuint(&ap, lflag);
			base = 16;
		number:
			printnum(putch, putdat, num, base, width, padc);
			break;

		// escaped '%' character
		case '%':
			putch(ch, putdat);
			break;

		// unrecognized escape sequence - just print it literally
		default:
			putch('%', putdat);
			for (fmt--; fmt[-1] != '%'; fmt--)
				/* do nothing */;
			break;
		}
	}
}

void
printfmt(void (*putch)(int, void*), void *putdat, const char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	vprintfmt(putch, putdat, fmt, ap);
	va_end(ap);
}

struct sprintbuf {
	char *buf;
	char *ebuf;
	int cnt;
};

static void
sprintputch(int ch, struct sprintbuf *b)
{
	b->cnt++;
	if (b->buf < b->ebuf)
		*b->buf++ = ch;
}

int
vsnprintf(char *buf, int n, const char *fmt, va_list ap)
{
	struct sprintbuf b = {buf, buf+n-1, 0};

	if (buf == NULL || n < 1)
		return -E_INVAL;

	// print the string to the buffer
	vprintfmt((void*)sprintputch, &b, fmt, ap);

	// null terminate the buffer
	*b.buf = '\0';

	return b.cnt;
}

int
snprintf(char *buf, int n, const char *fmt, ...)
{
	va_list ap;
	int rc;

	va_start(ap, fmt);
	rc = vsnprintf(buf, n, fmt, ap);
	va_end(ap);

	return rc;
}


